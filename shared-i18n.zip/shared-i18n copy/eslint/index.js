/**
 * @otrip/i18n-tools/eslint — ESLint plugin for Otrip i18n hygiene.
 *
 * Usage (flat config, eslint.config.js):
 *
 *   import otripI18n from '@otrip/i18n-tools/eslint'
 *
 *   export default [
 *     {
 *       plugins: { '@otrip/i18n': otripI18n },
 *       rules: {
 *         '@otrip/i18n/no-dynamic-translation-key': 'error',
 *       },
 *     },
 *   ]
 *
 * Usage (legacy config, .eslintrc):
 *
 *   {
 *     "plugins": ["@otrip/i18n-tools"],
 *     "rules": {
 *       "@otrip/i18n-tools/no-dynamic-translation-key": "error"
 *     }
 *   }
 */
'use strict'

const noDynamicTranslationKey = require('./rules/no-dynamic-translation-key.js')

module.exports = {
  rules: {
    'no-dynamic-translation-key': noDynamicTranslationKey,
  },
  configs: {
    recommended: {
      plugins: ['@otrip/i18n-tools'],
      rules: {
        '@otrip/i18n-tools/no-dynamic-translation-key': 'warn',
      },
    },
    strict: {
      plugins: ['@otrip/i18n-tools'],
      rules: {
        '@otrip/i18n-tools/no-dynamic-translation-key': 'error',
      },
    },
  },
}
