#!/usr/bin/env bun
/**
 * Lightweight self-test for the no-dynamic-translation-key rule.
 *
 * Doesn't pull in @typescript-eslint/parser or the full ESLint runtime —
 * we directly invoke the rule's `create()` against synthetic ESTree-shaped
 * AST nodes built from string fixtures via espree (ESLint's parser dep).
 *
 * Run: bun run eslint/test.js
 * Exits 0 on success, 1 on any failure.
 */
'use strict'

const espree = require('espree')
const rule = require('./rules/no-dynamic-translation-key.js')

const PARSE_OPTIONS = {
  ecmaVersion: 2023,
  sourceType: 'module',
  ecmaFeatures: { jsx: true },
}

function parseCode(code) {
  return espree.parse(code, PARSE_OPTIONS)
}

function runRule(code, options = []) {
  const ast = parseCode(code)
  const reports = []
  const ctx = {
    options,
    report(descriptor) {
      reports.push({
        messageId: descriptor.messageId,
        data: descriptor.data,
        line: descriptor.node?.loc?.start?.line,
      })
    },
  }
  const visitors = rule.create(ctx)

  function walk(node) {
    if (!node || typeof node !== 'object') return
    if (Array.isArray(node)) {
      for (const child of node) walk(child)
      return
    }
    if (typeof node.type === 'string') {
      const visitor = visitors[node.type]
      if (typeof visitor === 'function') visitor(node)
      for (const key of Object.keys(node)) {
        if (key === 'parent' || key === 'loc' || key === 'range') continue
        walk(node[key])
      }
    }
  }
  walk(ast)
  return reports
}

const cases = [
  {
    name: 'literal key passes',
    code: `t('foo')`,
    expectFailures: 0,
  },
  {
    name: 'literal key + literal namespace passes',
    code: `t('foo', 'common')`,
    expectFailures: 0,
  },
  {
    name: 'literal key + params object passes',
    code: `t('foo', 'common', { count: 1 })`,
    expectFailures: 0,
  },
  {
    name: 'variable key fails',
    code: `t(myVar)`,
    expectFailures: 1,
    expectMessageId: 'dynamicKey',
  },
  {
    name: 'template literal with expressions fails',
    code: 't(`prefix.${x}`)',
    expectFailures: 1,
    expectMessageId: 'dynamicKey',
  },
  {
    name: 'pure template (no expr) passes',
    code: 't(`literal`)',
    expectFailures: 0,
  },
  {
    name: 'conditional expression fails',
    code: `t(cond ? 'a' : 'b')`,
    expectFailures: 1,
  },
  {
    name: 'member access fails',
    code: `t(obj.key)`,
    expectFailures: 1,
  },
  {
    name: 'useTranslation literal passes',
    code: `useTranslation('common')`,
    expectFailures: 0,
  },
  {
    name: 'useTranslation variable fails',
    code: `useTranslation(ns)`,
    expectFailures: 1,
    expectMessageId: 'dynamicNs',
  },
  {
    name: 'useI18n no-arg passes',
    code: `useI18n()`,
    expectFailures: 0,
  },
  {
    name: 'tt alias literal passes',
    code: `tt('foo')`,
    expectFailures: 0,
  },
  {
    name: 'tt alias variable fails',
    code: `tt(myVar)`,
    expectFailures: 1,
  },
  {
    name: 'unrelated function call ignored',
    code: `console.log(myVar)`,
    expectFailures: 0,
  },
  {
    name: 'custom function via options',
    code: `myT(myVar)`,
    options: [{ functionNames: ['myT'] }],
    expectFailures: 1,
  },
]

let pass = 0
let fail = 0
for (const c of cases) {
  const reports = runRule(c.code, c.options ?? [])
  const ok = reports.length === c.expectFailures
    && (!c.expectMessageId || reports.every((r) => r.messageId === c.expectMessageId))
  if (ok) {
    pass++
    console.log(`\x1b[32m✓\x1b[0m ${c.name}`)
  } else {
    fail++
    console.log(`\x1b[31m✗\x1b[0m ${c.name}`)
    console.log(`   code: ${c.code}`)
    console.log(`   expected ${c.expectFailures} failures, got ${reports.length}`)
    if (c.expectMessageId) console.log(`   expected messageId: ${c.expectMessageId}`)
    console.log(`   reports: ${JSON.stringify(reports)}`)
  }
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail === 0 ? 0 : 1)
