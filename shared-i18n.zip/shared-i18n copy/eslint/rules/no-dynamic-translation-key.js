/**
 * ESLint rule: no-dynamic-translation-key
 *
 * Flags translation calls where the key (or namespace) cannot be statically
 * validated — i.e. the first arg to `t()` is a variable, template literal,
 * member expression, or computed value.
 *
 * Why: dynamic keys can't be compared against the Tolgee bundle at build time,
 * so missing translations slip past CI. Refactor to a literal map instead.
 *
 * Allowed:
 *   t('foo')
 *   t('foo', 'common')
 *   t('foo', 'common', { count })
 *   tt('foo')                                    // alias of t
 *   useTranslation('common')
 *
 * Flagged:
 *   t(myVar)
 *   t(`prefix.${x}`)
 *   t(cond ? 'a' : 'b')
 *   t(obj.key)
 *   useTranslation(myNs)
 *
 * Escape hatch: `// eslint-disable-next-line @otrip/i18n/no-dynamic-translation-key`
 *
 * Options:
 *   functionNames: string[]  — additional translation function names to check
 *                              beyond the defaults ['t', 'tt', 'tc'].
 *   hookNames: string[]      — additional hook names beyond ['useTranslation', 'useI18n'].
 */
'use strict'

const DEFAULT_FUNCTION_NAMES = ['t', 'tt', 'tc']
const DEFAULT_HOOK_NAMES = ['useTranslation', 'useI18n']

function isStaticString(node) {
  if (!node) return true
  if (node.type === 'Literal' && typeof node.value === 'string') return true
  if (node.type === 'TemplateLiteral' && node.expressions.length === 0) return true
  return false
}

module.exports = {
  meta: {
    type: 'problem',
    docs: {
      description: 'Disallow dynamic (non-literal) translation keys and namespaces',
      recommended: true,
    },
    schema: [
      {
        type: 'object',
        properties: {
          functionNames: {
            type: 'array',
            items: { type: 'string' },
          },
          hookNames: {
            type: 'array',
            items: { type: 'string' },
          },
        },
        additionalProperties: false,
      },
    ],
    messages: {
      dynamicKey: "Translation key passed to '{{name}}()' must be a string literal. Refactor to a literal map (e.g., switch on the variable and call t() with the corresponding literal in each branch).",
      dynamicNs: "Namespace passed to '{{name}}()' must be a string literal.",
    },
  },

  create(context) {
    const options = context.options[0] || {}
    const fnNames = new Set([
      ...DEFAULT_FUNCTION_NAMES,
      ...(options.functionNames || []),
    ])
    const hookNames = new Set([
      ...DEFAULT_HOOK_NAMES,
      ...(options.hookNames || []),
    ])

    return {
      CallExpression(node) {
        const callee = node.callee
        if (callee.type !== 'Identifier') return

        // Translation function call: t(key, ns?, ...)
        if (fnNames.has(callee.name)) {
          if (node.arguments.length === 0) return
          const keyArg = node.arguments[0]
          if (!isStaticString(keyArg)) {
            context.report({
              node: keyArg,
              messageId: 'dynamicKey',
              data: { name: callee.name },
            })
          }
          if (node.arguments.length >= 2) {
            const nsArg = node.arguments[1]
            // Namespace is optional — only flag if it's a string-shaped expression
            // that ISN'T a literal (e.g. a template literal or string variable).
            // Object literals (params) and other shapes are valid second args.
            if (nsArg.type === 'TemplateLiteral' && nsArg.expressions.length > 0) {
              context.report({
                node: nsArg,
                messageId: 'dynamicNs',
                data: { name: callee.name },
              })
            }
          }
          return
        }

        // Hook call: useTranslation(ns?), useI18n()
        if (hookNames.has(callee.name)) {
          if (node.arguments.length === 0) return
          const nsArg = node.arguments[0]
          if (!isStaticString(nsArg)) {
            context.report({
              node: nsArg,
              messageId: 'dynamicNs',
              data: { name: callee.name },
            })
          }
        }
      },
    }
  },
}
