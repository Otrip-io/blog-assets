#!/usr/bin/env bun
/**
 * tolgee:import — Apply the changes from tolgee-audit.json back to Tolgee.
 *
 * Reads tolgee-audit.json and for each entry:
 *   action: "move"   → PATCH the key's namespace in Tolgee (translations preserved)
 *   action: "both"   → PATCH namespace + create a copy in the other namespace
 *   action: "keep"   → skip (no change)
 *   action: "create" → POST new key with EN translation
 *   action: "delete" → DELETE key from Tolgee
 *   action: "skip"   → skip
 *
 * Usage:
 *   TOLGEE_API_KEY=tgpak_... bun run tolgee:import
 *   TOLGEE_API_KEY=tgpak_... bun run tolgee:import --dry   (preview only, no changes)
 */
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const TOLGEE_URL     = process.env.TOLGEE_URL ?? 'https://i18n.otrip.io'
const TOLGEE_PROJECT = process.env.TOLGEE_PROJECT ?? '2'
const TOLGEE_KEY     = process.env.TOLGEE_API_KEY
const DRY            = process.argv.includes('--dry')
const INPUT          = resolve(process.cwd(), 'tolgee-audit.json')

if (!TOLGEE_KEY) {
  console.error('❌  Set TOLGEE_API_KEY env var')
  process.exit(1)
}

const BASE = `${TOLGEE_URL}/v2/projects/${TOLGEE_PROJECT}`
const HEADERS = { 'X-API-Key': TOLGEE_KEY, 'Content-Type': 'application/json', Accept: 'application/json' }

async function tFetch(path: string, method = 'GET', body?: unknown): Promise<unknown> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: HEADERS,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  })
  if (res.status === 204) return null
  const text = await res.text()
  if (!res.ok) throw new Error(`${method} ${path} → ${res.status}: ${text.slice(0, 200)}`)
  return text ? JSON.parse(text) : null
}

// Move a key to a new namespace (PUT rename — preserves all translations)
async function moveKey(keyId: number, keyName: string, newNs: string): Promise<void> {
  await tFetch(`/keys/${keyId}`, 'PUT', {
    name: keyName,
    namespace: newNs,
  })
}

// Create a new key with EN translation
async function createKey(keyName: string, ns: string, en: string): Promise<void> {
  await tFetch('/keys', 'POST', {
    name: keyName,
    namespace: ns,
    translations: { en },
  })
}

// Delete a key
async function deleteKey(keyId: number): Promise<void> {
  await tFetch(`/keys/${keyId}`, 'DELETE')
}

// Get namespace ID (create if not exists)
async function ensureNamespace(name: string): Promise<void> {
  // Tolgee creates namespaces automatically when you create a key with that namespace
  void name
}

async function main() {
  console.log(`📖 Loading tolgee-audit.json...`)
  let audit: {
    moves: Array<{ key: string; currentNs: string; suggestedNs: string; _id: number; action: string; en: string }>
    new_keys: Array<{ key: string; suggestedNs: string; en: string; action: string }>
    orphans: Array<{ key: string; currentNs: string; _id: number; action: string }>
  }

  try {
    const raw = JSON.parse(await readFile(INPUT, 'utf8'))
    audit = raw
  } catch {
    console.error(`❌ ${INPUT} not found. Run: bun run tolgee:audit first`)
    process.exit(1)
  }

  if (DRY) console.log(`\n🔍 DRY RUN — no changes will be made\n`)

  const stats = { moved: 0, created: 0, deleted: 0, skipped: 0, failed: 0 }

  // ── MOVES ────────────────────────────────────────────────────────────────────
  const toMove = (audit.moves ?? []).filter(m => m.action === 'move' || m.action === 'both')
  if (toMove.length) {
    console.log(`\n🔀 Moving ${toMove.length} keys to correct namespaces...`)
    for (const item of toMove) {
      const label = `${item.currentNs}.${item.key} → ${item.suggestedNs}.${item.key}`
      if (DRY) { console.log(`   [DRY] move: ${label}`); stats.moved++; continue }
      try {
        await moveKey(item._id, item.key, item.suggestedNs)

        // If action is "both", also create a copy in currentNs
        if (item.action === 'both') {
          await createKey(item.key, item.currentNs, item.en)
          console.log(`   ✅ both: ${label} + kept copy in ${item.currentNs}`)
        } else {
          console.log(`   ✅ moved: ${label}`)
        }
        stats.moved++
        // Small delay to avoid Tolgee rate limits
        await new Promise(r => setTimeout(r, 50))
      } catch (err) {
        console.error(`   ❌ failed: ${label} — ${(err as Error).message}`)
        stats.failed++
      }
    }
  }

  // ── NEW KEYS ─────────────────────────────────────────────────────────────────
  const toCreate = (audit.new_keys ?? []).filter(k => k.action === 'create' && k.en?.trim())
  const noEn     = (audit.new_keys ?? []).filter(k => k.action === 'create' && !k.en?.trim())

  if (noEn.length) {
    console.log(`\n⚠️  ${noEn.length} new keys have no English text — skipping them.`)
    console.log(`   Fill in "en" in tolgee-audit.json and re-run.`)
    noEn.forEach(k => console.log(`   - ${k.suggestedNs}.${k.key}`))
  }

  if (toCreate.length) {
    console.log(`\n➕ Creating ${toCreate.length} new keys...`)
    for (const item of toCreate) {
      const label = `${item.suggestedNs}.${item.key} = "${item.en}"`
      if (DRY) { console.log(`   [DRY] create: ${label}`); stats.created++; continue }
      try {
        await createKey(item.key, item.suggestedNs, item.en)
        console.log(`   ✅ created: ${label}`)
        stats.created++
        await new Promise(r => setTimeout(r, 50))
      } catch (err) {
        const msg = (err as Error).message
        if (/key_exists/i.test(msg)) {
          console.log(`   ⏭  exists:  ${item.suggestedNs}.${item.key}`)
          stats.skipped++
        } else {
          console.error(`   ❌ failed: ${label} — ${msg}`)
          stats.failed++
        }
      }
    }
  }

  // ── DELETIONS ────────────────────────────────────────────────────────────────
  const toDelete = (audit.orphans ?? []).filter(o => o.action === 'delete')
  if (toDelete.length) {
    console.log(`\n🗑  Deleting ${toDelete.length} orphan keys...`)
    for (const item of toDelete) {
      const label = `${item.currentNs}.${item.key}`
      if (DRY) { console.log(`   [DRY] delete: ${label}`); stats.deleted++; continue }
      try {
        await deleteKey(item._id)
        console.log(`   ✅ deleted: ${label}`)
        stats.deleted++
        await new Promise(r => setTimeout(r, 50))
      } catch (err) {
        console.error(`   ❌ failed: ${label} — ${(err as Error).message}`)
        stats.failed++
      }
    }
  }

  // ── SUMMARY ──────────────────────────────────────────────────────────────────
  console.log(`\n${'─'.repeat(50)}`)
  console.log(DRY ? '📋 DRY RUN summary (no changes made):' : '✅ Import complete:')
  console.log(`   Moved:   ${stats.moved}`)
  console.log(`   Created: ${stats.created}`)
  console.log(`   Deleted: ${stats.deleted}`)
  console.log(`   Skipped: ${stats.skipped}`)
  if (stats.failed) console.log(`   Failed:  ${stats.failed}  ← check errors above`)

  if (!DRY && (stats.moved + stats.created) > 0) {
    console.log(`\n⚠️  Remember to purge the api-service Redis cache!`)
    console.log(`   Admin panel → i18n → Purge cache`)
  }
}

main().catch(err => { console.error('❌', err.message); process.exit(1) })
