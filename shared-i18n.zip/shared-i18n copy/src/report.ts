#!/usr/bin/env bun
/**
 * i18n:report — beautiful HTML report that opens in the browser.
 *
 * File links use vscode:// protocol so clicking a line opens it in VSCode.
 *
 * Usage (from web-app/ or mobile-app/):
 *   bun run i18n:report               → scan + generate + open in browser
 *   bun run i18n:report --no-open     → just write the file
 *   bun run i18n:report --hardcoded   → include hardcoded-string detection
 */
import { scan, type ScanOptions } from './scan.js'
import { fetchServerKeys, compare, type Issue } from './compare.js'
import { writeFile } from 'node:fs/promises'
import { resolve, relative, basename } from 'node:path'
import { spawnSync } from 'node:child_process'

const API_BASE   = process.env.I18N_API_BASE ?? 'https://apidev.otrip.io/api/v1'
const CWD        = process.cwd()
const ROOTS      = process.argv.flatMap((a, i, arr) => a === '--root' ? [arr[i + 1]!] : []).filter(Boolean)
const NO_OPEN    = process.argv.includes('--no-open')
const HARDCODED  = process.argv.includes('--hardcoded')
const OUTPUT     = resolve(CWD, 'i18n-report.html')
const TOLGEE_URL = 'https://i18n.otrip.io'
const PROJECT    = basename(CWD)

if (!ROOTS.length) { console.error('Pass --root <path>'); process.exit(2) }

function vsLink(file: string, line: number): string {
  const abs = resolve(CWD, file)
  const rel = relative(CWD, abs)
  return `<a class="code-link" href="vscode://file/${abs}:${line}" title="Open in VSCode">${rel}:${line}</a>`
}

function tolgeeSearchLink(key: string, label: string): string {
  return `<a class="tolgee-link" href="${TOLGEE_URL}/projects/2/translations?search=${encodeURIComponent(key)}" target="_blank">${label}</a>`
}

function pct(hits: number, total: number): number {
  return total > 0 ? Math.round((hits / total) * 100) : 100
}

function pctBar(p: number): string {
  const color = p === 100 ? '#22c55e' : p >= 90 ? '#f59e0b' : '#ef4444'
  return `<div class="bar-wrap"><div class="bar-fill" style="width:${p}%;background:${color}"></div></div>`
}

function groupBy<T>(arr: T[], key: (x: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>()
  for (const x of arr) {
    const k = key(x)
    ;(m.get(k) ?? m.set(k, []).get(k)!).push(x)
  }
  return m
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

async function main() {
  console.log('🔍 Scanning source files...')
  const scanResult = await scan(ROOTS, CWD, { detectHardcoded: HARDCODED } satisfies ScanOptions)

  console.log(`📡 Fetching key inventory from Tolgee (via ${API_BASE})...`)
  let server
  try {
    server = await fetchServerKeys(API_BASE)
  } catch (err) {
    console.error('❌ Cannot reach api-service:', (err as Error).message)
    process.exit(2)
  }

  const result   = compare(scanResult.calls, scanResult.dynamic, scanResult.hardcoded, server)
  const missing  = result.issues.filter(i => i.type === 'MISSING_KEY')
  const wrongNs  = result.issues.filter(i => i.type === 'WRONG_NAMESPACE')
  const dynamic  = result.issues.filter(i => i.type === 'DYNAMIC_KEY')
  const hard     = result.issues.filter(i => i.type === 'HARDCODED_STRING')
  const blockers = missing.length + wrongNs.length + (HARDCODED ? hard.length : 0)
  const coverage = pct(result.hits, result.totalCalls)
  const now      = new Date().toLocaleString()

  // ─────────────────────────────────────────────────────── CSS + HEAD ───────
  const css = `
  :root { --red:#ef4444;--yellow:#f59e0b;--green:#22c55e;--blue:#3b82f6;--bg:#f8fafc;--card:#fff;--border:#e2e8f0;--text:#1e293b;--muted:#64748b }
  * { box-sizing:border-box; margin:0; padding:0 }
  body { font-family: -apple-system, 'Segoe UI', sans-serif; background:var(--bg); color:var(--text); font-size:14px; line-height:1.6 }
  .container { max-width:1100px; margin:0 auto; padding:32px 24px }
  h1 { font-size:28px; font-weight:700; margin-bottom:4px }
  h2 { font-size:18px; font-weight:600; margin:28px 0 12px; display:flex; align-items:center; gap:8px }
  h3 { font-size:14px; font-weight:600; margin:20px 0 8px; color:var(--muted) }
  .meta { color:var(--muted); font-size:13px; margin-bottom:28px }
  .cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:12px; margin-bottom:28px }
  .card { background:var(--card); border:1px solid var(--border); border-radius:12px; padding:16px }
  .card .num { font-size:32px; font-weight:700; line-height:1 }
  .card .label { font-size:12px; color:var(--muted); margin-top:4px }
  .card.red .num { color:var(--red) }
  .card.yellow .num { color:var(--yellow) }
  .card.green .num { color:var(--green) }
  .card.blue .num { color:var(--blue) }
  .bar-wrap { background:#e2e8f0; border-radius:99px; height:10px; overflow:hidden; flex:1 }
  .bar-fill { height:100%; border-radius:99px; transition:width 0.4s }
  .coverage { display:flex; align-items:center; gap:12px; background:var(--card); border:1px solid var(--border); border-radius:12px; padding:16px 20px; margin-bottom:28px }
  .coverage .pct { font-size:24px; font-weight:700; min-width:56px }
  .coverage .details { font-size:12px; color:var(--muted); margin-top:2px }
  .section { background:var(--card); border:1px solid var(--border); border-radius:12px; margin-bottom:20px; overflow:hidden }
  .section-header { padding:14px 20px; cursor:pointer; display:flex; align-items:center; gap:10px; user-select:none }
  .section-header:hover { background:#f1f5f9 }
  .section-body { padding:0 20px 20px; display:none }
  .section-body.open { display:block }
  .badge { display:inline-flex; align-items:center; border-radius:6px; padding:2px 8px; font-size:12px; font-weight:600; white-space:nowrap }
  .badge.red { background:#fee2e2; color:var(--red) }
  .badge.yellow { background:#fef9c3; color:#a16207 }
  .badge.green { background:#dcfce7; color:#15803d }
  .badge.blue { background:#dbeafe; color:#1d4ed8 }
  table { width:100%; border-collapse:collapse; margin-top:8px; font-size:13px }
  th { text-align:left; padding:8px 12px; background:#f8fafc; border-bottom:1px solid var(--border); font-weight:600; color:var(--muted); font-size:12px }
  td { padding:8px 12px; border-bottom:1px solid #f1f5f9; vertical-align:top }
  tr:last-child td { border-bottom:none }
  tr:hover td { background:#fafafa }
  code { font-family: 'SF Mono', 'Fira Code', monospace; background:#f1f5f9; padding:1px 5px; border-radius:4px; font-size:12px }
  a { color:var(--blue); text-decoration:none }
  a:hover { text-decoration:underline }
  .code-link { color:#7c3aed; font-family:monospace; font-size:12px }
  .tolgee-link { color:var(--blue) }
  .howto { background:#f8fafc; border:1px solid var(--border); border-radius:10px; padding:16px 20px; margin-bottom:20px }
  .howto h3 { color:var(--text); margin-bottom:8px; font-size:14px }
  .howto ol, .howto ul { padding-left:20px; font-size:13px; color:var(--muted) }
  .howto li { margin-bottom:4px }
  pre { background:#1e293b; color:#e2e8f0; border-radius:8px; padding:14px 16px; overflow-x:auto; font-size:12px; font-family:monospace; margin:10px 0; line-height:1.6 }
  .ns-group { margin-bottom:16px }
  .ns-label { display:inline-block; background:#f1f5f9; border:1px solid var(--border); border-radius:6px; padding:3px 10px; font-size:12px; font-family:monospace; font-weight:600; margin-bottom:6px }
  .chevron { transition:transform 0.2s; margin-left:auto; color:var(--muted) }
  .chevron.open { transform:rotate(180deg) }
  .all-good { text-align:center; padding:40px; color:var(--green); font-size:16px; font-weight:600 }
  `

  const toggleScript = `
  function toggle(id) {
    const body = document.getElementById('body-'+id)
    const chev = document.getElementById('chev-'+id)
    body.classList.toggle('open')
    chev.classList.toggle('open')
  }
  // Open first two sections by default
  document.addEventListener('DOMContentLoaded', () => {
    const bodies = document.querySelectorAll('.section-body')
    bodies.forEach((b, i) => { if(i < 2) b.classList.add('open') })
    const chevs = document.querySelectorAll('.chevron')
    chevs.forEach((c, i) => { if(i < 2) c.classList.add('open') })
  })
  `

  // ─────────────────────────────────────────────────────── BODY ─────────────
  const parts: string[] = []

  // Header + summary cards
  parts.push(`<div class="container">`)
  parts.push(`<h1>i18n Status Report</h1>`)
  parts.push(`<p class="meta">Generated ${now} &nbsp;·&nbsp; Project: <code>${esc(PROJECT)}</code> &nbsp;·&nbsp; <a href="${TOLGEE_URL}/projects/2/translations" target="_blank">Open Tolgee ↗</a></p>`)

  parts.push(`<div class="cards">`)
  parts.push(`<div class="card green"><div class="num">${result.hits}</div><div class="label">✅ Keys resolved</div></div>`)
  parts.push(`<div class="card ${missing.length ? 'red' : 'green'}"><div class="num">${missing.length}</div><div class="label">❌ Missing key</div></div>`)
  parts.push(`<div class="card ${wrongNs.length ? 'red' : 'green'}"><div class="num">${wrongNs.length}</div><div class="label">⚠️ Wrong namespace</div></div>`)
  parts.push(`<div class="card ${dynamic.length ? 'yellow' : 'green'}"><div class="num">${dynamic.length}</div><div class="label">🟡 Dynamic key</div></div>`)
  if (HARDCODED) parts.push(`<div class="card ${hard.length ? 'red' : 'green'}"><div class="num">${hard.length}</div><div class="label">❌ Hardcoded string</div></div>`)
  parts.push(`<div class="card blue"><div class="num">${result.totalCalls}</div><div class="label">Total t() calls</div></div>`)
  parts.push(`</div>`)

  // Coverage bar
  const covColor = coverage === 100 ? 'var(--green)' : coverage >= 90 ? 'var(--yellow)' : 'var(--red)'
  parts.push(`<div class="coverage">`)
  parts.push(`<div class="pct" style="color:${covColor}">${coverage}%</div>`)
  parts.push(`<div style="flex:1">${pctBar(coverage)}<div class="details">${result.hits} of ${result.totalCalls} call sites resolve correctly &nbsp;·&nbsp; ${blockers} blocker${blockers !== 1 ? 's' : ''} to fix</div></div>`)
  parts.push(`</div>`)

  // ── How to fix guide ──
  const sections: Array<{ id: string; title: string; badge: string; bclass: string; content: string }> = []

  const guideContent = `
    <div class="howto">
      <h3>❌ MISSING_KEY — add the key to Tolgee</h3>
      <ol>
        <li>Click the <strong>[Add in Tolgee]</strong> link next to any key below</li>
        <li>Set the namespace exactly as shown (e.g. <code>trips</code>)</li>
        <li>Enter the <strong>English</strong> text — Tolgee AI auto-translates to Arabic and all other languages</li>
        <li>When done, go to <strong>Admin panel → Purge cache</strong></li>
        <li>Re-run <code>bun run i18n:report</code> — the count drops</li>
      </ol>
    </div>
    <div class="howto" style="margin-top:12px">
      <h3>⚠️ WRONG_NAMESPACE — change namespace in your code</h3>
      <ul>
        <li>The key exists in Tolgee, just in a different namespace</li>
        <li>Click the file link → change <code>'wrong_ns'</code> to the correct one shown</li>
        <li>No Tolgee changes needed</li>
      </ul>
    </div>
    <div class="howto" style="margin-top:12px">
      <h3>🟡 DYNAMIC_KEY — refactor <code>t(variable)</code> to a literal map</h3>
      <ul>
        <li>The scanner can't validate <code>t(item.labelKey, 'ns')</code> — the key is a variable</li>
        <li>Pattern: store the key strings in a <code>const</code> map, then index into it</li>
      </ul>
      <pre>// ❌ Before (dynamic — scanner can't check, may be missing in Tolgee)
const OPTIONS = [{ value: 'easy', labelKey: 'difficulty_easy' }]
t(opt.labelKey, 'packages')

// ✅ After (literal map — scanner validates every key)
const LABELS = {
  easy:   'difficulty_easy',
  medium: 'difficulty_medium',
  hard:   'difficulty_hard',
} as const
t(LABELS[opt.value], 'packages')  // runtime dynamic, but statically checkable</pre>
    </div>`

  sections.push({ id: 'guide', title: 'How to fix each type', badge: '📖 Read first', bclass: 'blue', content: guideContent })

  // ── MISSING_KEY section ──
  if (missing.length > 0) {
    const byNs = groupBy(missing, i => (i as any).call.namespace)
    let html = `<p style="color:var(--muted);font-size:13px;margin-bottom:16px">These keys are referenced in your code but <strong>don't exist in Tolgee</strong>. Users see the raw key name. Click [Add] to open Tolgee pre-filtered to that key.</p>`
    for (const [ns, items] of byNs.entries()) {
      html += `<div class="ns-group"><span class="ns-label">${esc(ns)}</span><table><thead><tr><th style="width:40%">File</th><th>Key</th><th style="width:80px">Action</th></tr></thead><tbody>`
      for (const i of items) {
        const c = (i as any).call
        html += `<tr><td>${vsLink(c.file, c.line)}</td><td><code>${esc(c.key)}</code></td><td>${tolgeeSearchLink(c.key, 'Add ↗')}</td></tr>`
      }
      html += `</tbody></table></div>`
    }
    sections.push({ id: 'missing', title: 'MISSING_KEY', badge: `${missing.length} to add in Tolgee`, bclass: 'red', content: html })
  } else {
    sections.push({ id: 'missing', title: 'MISSING_KEY', badge: '0 — all clear ✅', bclass: 'green', content: '<div class="all-good">✅ No missing keys!</div>' })
  }

  // ── WRONG_NAMESPACE section ──
  if (wrongNs.length > 0) {
    let html = `<p style="color:var(--muted);font-size:13px;margin-bottom:16px">These keys exist in Tolgee but your code uses the wrong namespace. Fix: change the namespace in the <code>t()</code> call.</p>`
    html += `<table><thead><tr><th style="width:40%">File</th><th>Called as</th><th>Key actually lives in</th><th>Fix</th></tr></thead><tbody>`
    for (const i of wrongNs) {
      const c = (i as any).call
      const exists = ((i as any).existsIn as string[])
      html += `<tr>
        <td>${vsLink(c.file, c.line)}</td>
        <td><code>${esc(c.namespace)}.${esc(c.key)}</code></td>
        <td>${exists.map(ns => `<code>${esc(ns)}</code>`).join(', ')}</td>
        <td>Change <code>'${esc(c.namespace)}'</code> → <code>'${esc(exists[0])}'</code></td>
      </tr>`
    }
    html += `</tbody></table>`
    sections.push({ id: 'wrong', title: 'WRONG_NAMESPACE', badge: `${wrongNs.length} quick code fixes`, bclass: 'red', content: html })
  } else {
    sections.push({ id: 'wrong', title: 'WRONG_NAMESPACE', badge: '0 — all clear ✅', bclass: 'green', content: '<div class="all-good">✅ All namespaces correct!</div>' })
  }

  // ── DYNAMIC_KEY section ──
  if (dynamic.length > 0) {
    const byFile = groupBy(dynamic, i => (i as any).site.file)
    let html = `<p style="color:var(--muted);font-size:13px;margin-bottom:16px">These use a variable as the translation key — the scanner can't verify they exist in Tolgee. Refactor to literal maps (see guide above). Not a build blocker but a quality risk.</p>`
    for (const [file, items] of byFile.entries()) {
      const rel = relative(CWD, resolve(CWD, file))
      html += `<div class="ns-group"><span class="ns-label">${esc(rel)}</span><table><thead><tr><th style="width:120px">Line</th><th>Dynamic call</th></tr></thead><tbody>`
      for (const i of items) {
        const s = (i as any).site
        html += `<tr><td>${vsLink(s.file, s.line)}</td><td><code>${esc(s.snippet)}</code></td></tr>`
      }
      html += `</tbody></table></div>`
    }
    sections.push({ id: 'dynamic', title: 'DYNAMIC_KEY', badge: `${dynamic.length} warnings (not blockers)`, bclass: 'yellow', content: html })
  }

  // ── HARDCODED_STRING section ──
  if (HARDCODED) {
    if (hard.length > 0) {
      const byFile = groupBy(hard, i => (i as any).site.file)
      let html = `<p style="color:var(--muted);font-size:13px;margin-bottom:16px">English text directly in JSX — Arabic users see English. Wrap in <code>t()</code> using the suggested key.</p>`
      for (const [file, items] of byFile.entries()) {
        const rel = relative(CWD, resolve(CWD, file))
        html += `<div class="ns-group"><span class="ns-label">${esc(rel)}</span><table><thead><tr><th style="width:120px">Line</th><th>Text found</th><th>Suggested fix</th></tr></thead><tbody>`
        for (const i of items) {
          const s = (i as any).site
          const fix = s.origin.kind === 'child'
            ? `t('${esc(s.suggestedKey)}', 'common')`
            : `${esc(s.origin.prop)}={t('${esc(s.suggestedKey)}', 'common')}`
          html += `<tr><td>${vsLink(s.file, s.line)}</td><td><code>${esc(s.text.slice(0, 50))}</code></td><td><code>${fix}</code></td></tr>`
        }
        html += `</tbody></table></div>`
      }
      sections.push({ id: 'hard', title: 'HARDCODED_STRING', badge: `${hard.length} to wrap`, bclass: 'red', content: html })
    } else {
      sections.push({ id: 'hard', title: 'HARDCODED_STRING', badge: '0 — all clear ✅', bclass: 'green', content: '<div class="all-good">✅ No hardcoded strings!</div>' })
    }
  }

  // ── Next steps card ──
  let nextHtml = `<ol style="padding-left:20px;font-size:14px;line-height:2">`
  nextHtml += `<li><strong>Fix WRONG_NAMESPACE (${wrongNs.length})</strong> — fastest win, just change namespace in code, no Tolgee needed</li>`
  nextHtml += `<li><strong>Add MISSING_KEY (${missing.length}) to Tolgee</strong> — grouped by namespace above, click Add links</li>`
  nextHtml += `<li><strong>Refactor DYNAMIC_KEY (${dynamic.length})</strong> — use literal maps, grouped by file above</li>`
  if (HARDCODED && hard.length) nextHtml += `<li><strong>Wrap HARDCODED_STRING (${hard.length})</strong> — add <code>t()</code> + key to Tolgee</li>`
  nextHtml += `<li><strong>Re-run report</strong>: <code>bun run i18n:report</code></li>`
  nextHtml += `<li><strong>When blockers hit 0</strong>: add <code>bun run i18n:check:strict</code> to CI — nobody can ship a missing translation again</li>`
  nextHtml += `</ol>`
  sections.push({ id: 'next', title: 'Next steps', badge: `${blockers} blockers remaining`, bclass: blockers ? 'yellow' : 'green', content: nextHtml })

  // Render collapsible sections
  for (const s of sections) {
    parts.push(`<div class="section">`)
    parts.push(`  <div class="section-header" onclick="toggle('${s.id}')">`)
    parts.push(`    <span style="font-size:16px;font-weight:600">${esc(s.title)}</span>`)
    parts.push(`    <span class="badge ${s.bclass}">${esc(s.badge)}</span>`)
    parts.push(`    <svg id="chev-${s.id}" class="chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>`)
    parts.push(`  </div>`)
    parts.push(`  <div id="body-${s.id}" class="section-body">${s.content}</div>`)
    parts.push(`</div>`)
  }

  parts.push(`<p style="text-align:center;color:var(--muted);font-size:12px;margin-top:32px">Generated by <code>bun run i18n:report</code> · <a href="${TOLGEE_URL}" target="_blank">Tolgee</a> · Timing: scan ${result.issues.length}ms</p>`)
  parts.push(`</div>`)

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>i18n Report — ${esc(PROJECT)}</title>
  <style>${css}</style>
</head>
<body>
${parts.join('\n')}
<script>${toggleScript}</script>
</body>
</html>`

  await writeFile(OUTPUT, html, 'utf8')
  console.log(`✅ Report written → ${OUTPUT}`)
  console.log(`   ${missing.length} MISSING  ${wrongNs.length} WRONG_NS  ${dynamic.length} DYNAMIC${HARDCODED ? `  ${hard.length} HARDCODED` : ''}  |  coverage ${coverage}%`)

  if (!NO_OPEN) {
    // open in default browser (macOS: open, Linux: xdg-open, Windows: start)
    const opener = process.platform === 'darwin' ? 'open'
      : process.platform === 'win32' ? 'start'
      : 'xdg-open'
    const r = spawnSync(opener, [OUTPUT], { stdio: 'inherit' })
    if (r.error) console.log(`\n💡 To open: ${opener} "${OUTPUT}"`)
  }
}

main().catch(err => { console.error('❌', err); process.exit(2) })
