#!/usr/bin/env bun
/**
 * tolgee:audit — Cross-reference every Tolgee key against actual code usage.
 *
 * For each key in tolgee-export.json it checks:
 *   1. Which namespace does the CODE use it under? (from t() call sites)
 *   2. Which files use it? (used to infer feature context)
 *   3. Is it used at all? (orphan detection)
 *   4. Does the key name follow snake_case rules?
 *
 * Produces tolgee-audit.json — review this, edit it, then run tolgee:import.
 *
 * Usage:
 *   bun run tolgee:audit --root ../mobile-app/app --root ../mobile-app/src --root ../web-app/src
 */
import { readFile, writeFile } from 'node:fs/promises'
import { resolve, relative } from 'node:path'
import { scan } from './scan.js'

const CWD    = process.cwd()
const OUTPUT = resolve(CWD, 'tolgee-audit.json')
const INPUT  = resolve(CWD, 'tolgee-export.json')

const ROOTS = process.argv
  .flatMap((a, i, arr) => a === '--root' ? [arr[i + 1]!] : [])
  .filter(Boolean)

if (!ROOTS.length) {
  console.error('Pass --root <path> (repeat for multiple)')
  process.exit(2)
}

// ── Namespace taxonomy: which file-path patterns belong to which namespace ──
// Ordered most-specific first.
const FILE_CONTEXT: Array<{ pattern: RegExp; namespace: string }> = [
  { pattern: /\/(auth|login|register|forgot-password|otp|complete-profile|onboarding)/i, namespace: 'auth' },
  { pattern: /\/settings\//i,                    namespace: 'settings' },
  { pattern: /\/chat\//i,                        namespace: 'chat' },
  { pattern: /\/messages?\//i,                   namespace: 'chat' },
  { pattern: /\/notifications?\//i,              namespace: 'notifications' },
  { pattern: /\/trip\/|\/trips?\//i,             namespace: 'trips' },
  { pattern: /\/package\/|\/packages?\//i,       namespace: 'packages' },
  { pattern: /\/discover\//i,                    namespace: 'discover' },
  { pattern: /\/profile\//i,                     namespace: 'profile' },
  { pattern: /\/subscription\//i,               namespace: 'settings' },
  { pattern: /\/leaderboard\//i,                namespace: 'discover' },
  { pattern: /\/activity\//i,                   namespace: 'navigation' },
  { pattern: /\/media\//i,                      namespace: 'media' },
  { pattern: /\/expense|\/transaction/i,         namespace: 'trips' },
  { pattern: /\/reels?\//i,                     namespace: 'common' },
  { pattern: /\/home\//i,                       namespace: 'home' },
  { pattern: /\/broadcasts?\//i,                namespace: 'broadcasts' },
]

// Words that are generic enough for `common` regardless of file location
const COMMON_WORDS = new Set([
  'save','cancel','delete','edit','confirm','done','back','close','submit',
  'continue','next','previous','retry','dismiss','loading','error','success',
  'warning','info','ok','yes','no','or','and','search','clear','reset',
  'apply','update','create','add','remove','select','skip','finish','start',
  'stop','play','pause','mute','unmute','upload','download','share','copy',
  'paste','open','view','hide','show','more','less','all','none','other',
  'unknown','optional','required','new','save_changes','discard','undo',
  'month','year','day','hour','minute','second','answer','message','send',
  'reply','comment','like','follow','unfollow','block','report','flag',
  'read_more','see_all','go_back','try_again','refresh','reload',
])

function inferNsFromFiles(files: string[]): string | null {
  const counts: Record<string, number> = {}
  for (const f of files) {
    for (const { pattern, namespace } of FILE_CONTEXT) {
      if (pattern.test(f)) {
        counts[namespace] = (counts[namespace] ?? 0) + 1
        break
      }
    }
  }
  if (!Object.keys(counts).length) return null
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0]
}

function isCommonCandidate(key: string, en: string, codNs: Set<string>): boolean {
  const keyWords = key.toLowerCase().split('_')
  if (keyWords.every(w => COMMON_WORDS.has(w) || w.length <= 2)) return true
  if (codNs.size >= 3) return true  // used in 3+ different namespaces → common
  const enWords = en.toLowerCase().split(/\s+/)
  if (enWords.length <= 2 && COMMON_WORDS.has(enWords[0])) return true
  return false
}

async function main() {
  console.log('📖 Loading tolgee-export.json...')
  let exported: Record<string, Record<string, { en: string; _id: number }>>
  try {
    exported = JSON.parse(await readFile(INPUT, 'utf8'))
  } catch {
    console.error(`❌ ${INPUT} not found. Run: TOLGEE_API_KEY=xxx bun run tolgee:export`)
    process.exit(1)
  }

  const totalKeys = Object.values(exported).reduce((a, v) => a + Object.keys(v).length, 0)
  console.log(`   ${totalKeys} keys across ${Object.keys(exported).length} namespaces`)

  console.log(`\n🔍 Scanning source code for t() call sites...`)
  const scanResult = await scan(ROOTS, CWD)

  // Build map: key → { codeNamespaces: Set, files: string[] }
  const codeUsage = new Map<string, { nsByCode: Set<string>; files: string[] }>()
  for (const call of scanResult.calls) {
    const existing = codeUsage.get(call.key)
    if (existing) {
      existing.nsByCode.add(call.namespace)
      if (!existing.files.includes(call.file)) existing.files.push(call.file)
    } else {
      codeUsage.set(call.key, { nsByCode: new Set([call.namespace]), files: [call.file] })
    }
  }
  console.log(`   ${scanResult.calls.length} call sites | ${codeUsage.size} unique keys in code`)

  // ── Audit every Tolgee key ──────────────────────────────────────────────────
  const moves:     Array<Record<string, unknown>> = []
  const ok:        Array<Record<string, unknown>> = []
  const orphans:   Array<Record<string, unknown>> = []
  const newKeys:   Array<Record<string, unknown>> = []  // in code but not in Tolgee

  for (const [tNs, keys] of Object.entries(exported)) {
    for (const [keyName, { en, _id }] of Object.entries(keys)) {
      const usage = codeUsage.get(keyName)

      if (!usage) {
        // Key is in Tolgee but never used in scanned code
        orphans.push({ key: keyName, currentNs: tNs, en, _id, reason: 'Not found in code' })
        continue
      }

      const { nsByCode, files } = usage
      const relFiles = files.map(f => relative(CWD, resolve(CWD, f)))

      // Check if Tolgee namespace matches what code uses
      const codeNsArr = [...nsByCode]
      const codeNsStr = codeNsArr.join(', ')
      const allCodeAgree = codeNsArr.length === 1
      const codeNsMatches = nsByCode.has(tNs)

      // Determine recommended namespace
      let recommended = tNs
      let reason = ''

      if (isCommonCandidate(keyName, en, nsByCode)) {
        recommended = 'common'
        reason = 'Generic word used across features'
      } else if (allCodeAgree) {
        recommended = codeNsArr[0]
        reason = `Code always uses '${codeNsArr[0]}'`
      } else if (!codeNsMatches) {
        const fileInferred = inferNsFromFiles(relFiles)
        if (fileInferred) {
          recommended = fileInferred
          reason = `File path context suggests '${fileInferred}'`
        } else {
          recommended = codeNsArr[0]
          reason = `Code most often uses '${codeNsArr[0]}'`
        }
      }

      if (recommended !== tNs) {
        moves.push({
          key: keyName,
          currentNs: tNs,
          suggestedNs: recommended,
          en,
          _id,
          codeUses: codeNsStr,
          files: relFiles.slice(0, 5),
          reason,
          action: 'move',  // set to 'keep' to override and leave in current ns
        })
      } else {
        ok.push({ key: keyName, ns: tNs, en, _id })
      }
    }
  }

  // Keys in code that are NOT in Tolgee (missing from Tolgee)
  for (const [key, { nsByCode, files }] of codeUsage.entries()) {
    const inTolgee = Object.entries(exported).some(([, keys]) => key in keys)
    if (!inTolgee) {
      newKeys.push({
        key,
        suggestedNs: [...nsByCode][0],
        en: '',  // fill this in manually or infer from key name
        codeUses: [...nsByCode].join(', '),
        files: files.map(f => relative(CWD, resolve(CWD, f))).slice(0, 3),
        action: 'create',
      })
    }
  }

  const audit = {
    _readme: [
      'Review this file then run: bun run tolgee:import',
      '',
      'MOVES section: keys that appear to be in the wrong namespace.',
      '  • "action": "move"  → will move to suggestedNs (change namespace in Tolgee)',
      '  • "action": "keep"  → leave as-is (override if you disagree with the suggestion)',
      '  • "action": "both"  → keep in currentNs AND create copy in suggestedNs (different translation context)',
      '',
      'NEW_KEYS section: keys used in code but not in Tolgee.',
      '  • Fill in "en" value for each key before importing',
      '  • "action": "create" → will create in suggestedNs',
      '  • "action": "skip"   → do not create (e.g. dynamic key, handled elsewhere)',
      '',
      'ORPHANS section: keys in Tolgee not found in scanned code.',
      '  • "action": "delete" → will delete from Tolgee',
      '  • "action": "keep"   → leave as-is',
    ],
    summary: {
      totalTolgeeKeys:  totalKeys,
      totalCodeKeys:    codeUsage.size,
      alreadyCorrect:   ok.length,
      suggestedMoves:   moves.length,
      orphans:          orphans.length,
      missingInTolgee:  newKeys.length,
    },
    moves,
    new_keys: newKeys,
    orphans,
  }

  await writeFile(OUTPUT, JSON.stringify(audit, null, 2), 'utf8')

  console.log(`\n📊 Audit results:`)
  console.log(`   ✅ Already correct:   ${ok.length}`)
  console.log(`   🔀 Suggested moves:   ${moves.length}`)
  console.log(`   ❓ Not in code:       ${orphans.length}`)
  console.log(`   ➕ Missing in Tolgee: ${newKeys.length}`)
  console.log(`\n💾 Saved to: ${OUTPUT}`)
  console.log(`\nNext steps:`)
  console.log(`  1. Review tolgee-audit.json`)
  console.log(`     • Change "action": "keep" to override any move you disagree with`)
  console.log(`     • Fill in "en" values for new_keys`)
  console.log(`     • Change "action": "delete" on orphans you want removed`)
  console.log(`  2. Run: TOLGEE_API_KEY=xxx bun run tolgee:import`)
}

main().catch(err => { console.error('❌', err.message); process.exit(1) })
