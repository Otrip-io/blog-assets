/**
 * Configuration for the i18n scanner.
 *
 * Controls which functions are recognized as translation wrappers,
 * which JSX components/props are scanned for hardcoded strings,
 * and which patterns to skip.
 */

/**
 * Function names that act as translation hooks/factories.
 * The scanner tracks these to resolve the namespace bound to each `t` identifier.
 *
 * Pattern: `const { t } = useTranslation('ns')` or `const { t: alias } = useI18n()`
 */
export const TRANSLATION_HOOKS = new Set<string>([
  'useTranslation',  // `useTranslation('ns')` returns `{ t }` bound to ns
  'useI18n',         // `useI18n()` returns `{ t }` accepting explicit ns arg
])

/**
 * Skip files matching these patterns (test files, storybook, dev-only screens).
 */
export const SKIP_PATTERNS: RegExp[] = [
  /\.test\.[tj]sx?$/,
  /\.spec\.[tj]sx?$/,
  /__tests__\//,
  /\.stories\.[tj]sx?$/,
  /\bdev-[^/]+\.[tj]sx?$/,
  /__dev__\//,
]

/**
 * Skip these strings even when they look like keys (regex/exact).
 */
export const SKIP_LITERALS: Array<RegExp | string> = [
  /^https?:\/\//,                                // URLs
  /^mailto:/,                                    // mailto links
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/,                  // email addresses (often as link text)
  /^[#$@%].*/,                                   // single-symbol prefix
  /^\s*$/,                                       // empty / whitespace
  /^[0-9.,+\-_/:%$]+$/,                          // pure numeric/symbolic
  /^\d{4}-\d{2}-\d{2}/,                          // ISO dates
  /^[a-z]+:[a-z]/i,                              // protocol-like (file:, data:)
  /^v?\d+(\.\d+)+/,                              // version strings (v1.2, 2.0.1)
]

/**
 * Default values for unresolvable wrapper namespaces.
 * When `useTranslation()` is called without an argument, fall back to this.
 */
export const DEFAULT_NAMESPACE = 'common'

/**
 * JSX components whose string-literal children should be flagged as hardcoded text.
 * Web HTML elements + custom UI components shared by both apps.
 *
 * Lowercase entries match HTML elements (`<h1>foo</h1>`).
 * PascalCase entries match React components (`<Text>foo</Text>`).
 */
export const HARDCODED_TEXT_COMPONENTS = new Set<string>([
  // HTML
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
  'p', 'span', 'a', 'button', 'label',
  'option', 'summary', 'figcaption', 'caption',
  'th', 'td', 'li', 'dt', 'dd',
  'strong', 'em', 'b', 'i', 'small',
  'title',
  // Common React component names
  'Text', 'Heading', 'Label', 'Button', 'Pressable',
  'Title', 'Subtitle', 'Caption', 'Tag', 'Badge',
  'Toast', 'Tooltip', 'Chip',
])

/**
 * JSX props whose string-literal values should be flagged as hardcoded text,
 * on ANY element (allowlist by prop name, not by element).
 */
export const HARDCODED_TEXT_PROPS = new Set<string>([
  'title', 'label', 'placeholder',
  'accessibilityLabel', 'accessibilityHint',
  'aria-label', 'aria-description',
  'alt',
  'message', 'description', 'subtitle',
  'helperText', 'errorText', 'errorMessage',
  'confirmText', 'cancelText', 'submitText',
  'emptyText', 'emptyMessage', 'loadingText',
  'tooltip', 'header', 'heading',
  'caption',
])

/**
 * JSX props that look textual but aren't user-facing — never flag.
 */
export const SKIP_PROP_NAMES = new Set<string>([
  'name', 'id', 'key', 'className', 'style', 'sx',
  'testID', 'data-testid', 'data-test',
  'type', 'role', 'href', 'src', 'source',
  'value', 'defaultValue',
  'as', 'variant', 'size', 'color',
])

/**
 * Element-name regex patterns for SKIPPED parents — children of these
 * elements are never considered hardcoded UI strings (e.g., <code>, <pre>).
 */
export const SKIP_PARENT_COMPONENTS = new Set<string>([
  'code', 'pre', 'kbd', 'var', 'samp',
  'script', 'style', 'noscript',
  'CachedImage', 'Image', // src is the target, not text
])
