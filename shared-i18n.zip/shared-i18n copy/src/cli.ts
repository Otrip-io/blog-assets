#!/usr/bin/env bun
/**
 * `i18n:check` CLI — the strong script.
 *
 * Scans a project's source tree for `t()` translation call sites, fetches
 * the live key inventory from Tolgee (via api-service), and reports:
 *   • MISSING_KEY     — `t()` references a key not in Tolgee
 *   • WRONG_NAMESPACE — key exists but under a different namespace
 *   • DYNAMIC_KEY     — non-literal first arg can't be statically validated
 *
 * Usage:
 *   bun run cli.ts --root <path> [--root <path>] [--strict] [--json]
 *
 *   --root         Source tree to scan. Repeat for multiple. Required.
 *   --api          Override the api-service base URL. Default: $I18N_API_BASE
 *                  or https://apidev.otrip.io/api/v1.
 *   --strict       Exit non-zero on any blocker (MISSING_KEY, WRONG_NAMESPACE).
 *   --json         Emit machine-readable JSON instead of pretty terminal output.
 *
 * Exit codes (non-strict): always 0 unless the script crashes.
 * Exit codes (strict): 1 if any blocker is found, 0 otherwise.
 */

import { scan } from './scan.js'
import { fetchServerKeys, compare, type Issue } from './compare.js'

interface Args {
  roots: string[]
  api: string
  strict: boolean
  json: boolean
  hardcoded: boolean
}

function parseArgs(argv: string[]): Args {
  const args: Args = {
    roots: [],
    api: process.env.I18N_API_BASE ?? 'https://apidev.otrip.io/api/v1',
    strict: false,
    json: false,
    hardcoded: false,
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--root') args.roots.push(argv[++i] ?? '')
    else if (a === '--api') args.api = argv[++i] ?? args.api
    else if (a === '--strict') args.strict = true
    else if (a === '--json') args.json = true
    else if (a === '--hardcoded') args.hardcoded = true
    else if (a === '--help' || a === '-h') {
      printHelp()
      process.exit(0)
    } else {
      console.error(`Unknown arg: ${a}`)
      printHelp()
      process.exit(2)
    }
  }
  if (args.roots.length === 0) {
    console.error('--root is required')
    printHelp()
    process.exit(2)
  }
  return args
}

function printHelp(): void {
  console.error(`Usage: bun run cli.ts --root <path> [--root <path>] [--strict] [--json] [--hardcoded] [--api <url>]

  --root        Source tree to scan. Repeat for multiple. Required.
  --api         api-service base URL. Default: $I18N_API_BASE or https://apidev.otrip.io/api/v1.
  --strict      Exit non-zero on any blocker (MISSING_KEY, WRONG_NAMESPACE, HARDCODED_STRING when --hardcoded).
  --json        Emit JSON instead of pretty terminal output.
  --hardcoded   Also detect hardcoded UI strings in JSX. High signal but more false positives — review skip list before running --strict.`)
}

const RED = '\x1b[31m'
const YELLOW = '\x1b[33m'
const GREEN = '\x1b[32m'
const DIM = '\x1b[2m'
const RESET = '\x1b[0m'
const BOLD = '\x1b[1m'

function isBlocker(issue: Issue): boolean {
  return issue.type === 'MISSING_KEY' || issue.type === 'WRONG_NAMESPACE' || issue.type === 'HARDCODED_STRING'
}

function describe(issue: Issue): string {
  if (issue.type === 'MISSING_KEY') {
    const c = issue.call
    return `${RED}✖ MISSING_KEY${RESET}    ${c.file}:${c.line}\n` +
      `   ${DIM}t('${c.key}', '${c.namespace}')${RESET} — key not in Tolgee\n` +
      `   ${DIM}Add via Tolgee UI (https://i18n.otrip.io) or local overlay${RESET}`
  }
  if (issue.type === 'WRONG_NAMESPACE') {
    const c = issue.call
    const places = issue.existsIn.map((ns) => `${ns}.${c.key}`).join(', ')
    return `${RED}✖ WRONG_NAMESPACE${RESET} ${c.file}:${c.line}\n` +
      `   ${DIM}t('${c.key}', '${c.namespace}')${RESET} — key exists at: ${BOLD}${places}${RESET}\n` +
      `   ${DIM}Either change the call namespace or rename the existing key${RESET}`
  }
  if (issue.type === 'HARDCODED_STRING') {
    const s = issue.site
    const where = s.origin.kind === 'child'
      ? `<${s.origin.component}>${s.text}</${s.origin.component}>`
      : `<${s.origin.component} ${s.origin.prop}="${s.text}" />`
    const fix = s.origin.kind === 'child'
      ? `<${s.origin.component}>{t('${s.suggestedKey}', 'common')}</${s.origin.component}>`
      : `<${s.origin.component} ${s.origin.prop}={t('${s.suggestedKey}', 'common')} />`
    return `${RED}✖ HARDCODED_STRING${RESET} ${s.file}:${s.line}\n` +
      `   ${DIM}${where}${RESET}\n` +
      `   ${DIM}Fix: ${fix}${RESET}`
  }
  // DYNAMIC_KEY
  const s = issue.site
  return `${YELLOW}⚠ DYNAMIC_KEY${RESET}    ${s.file}:${s.line}\n` +
    `   ${DIM}${s.snippet}${RESET}\n` +
    `   ${DIM}Can't statically validate; refactor to a literal map${RESET}`
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const cwd = process.cwd()

  const scanStart = Date.now()
  const scanResult = await scan(args.roots, cwd, { detectHardcoded: args.hardcoded })
  const scanMs = Date.now() - scanStart

  const fetchStart = Date.now()
  let server
  try {
    server = await fetchServerKeys(args.api)
  } catch (err) {
    console.error(`${RED}fetch failed:${RESET} ${(err as Error).message}`)
    console.error(`Hint: ensure api-service is reachable at ${args.api}`)
    process.exit(2)
  }
  const fetchMs = Date.now() - fetchStart

  const result = compare(scanResult.calls, scanResult.dynamic, scanResult.hardcoded, server)

  if (args.json) {
    console.log(JSON.stringify({
      filesScanned: scanResult.filesScanned,
      totalCalls: result.totalCalls,
      hits: result.hits,
      issues: result.issues,
      timing: { scanMs, fetchMs },
    }, null, 2))
  } else {
    const blockers = result.issues.filter(isBlocker)
    const warnings = result.issues.filter((i) => !isBlocker(i))

    // Print issues
    for (const issue of result.issues) {
      console.log(describe(issue))
      console.log()
    }

    // Summary
    const missingCount = result.issues.filter((i) => i.type === 'MISSING_KEY').length
    const wrongNsCount = result.issues.filter((i) => i.type === 'WRONG_NAMESPACE').length
    const hardcodedCount = result.issues.filter((i) => i.type === 'HARDCODED_STRING').length
    const dynamicCount = result.issues.filter((i) => i.type === 'DYNAMIC_KEY').length

    console.log(`${BOLD}Summary${RESET}`)
    console.log(`  Files scanned:        ${scanResult.filesScanned}`)
    console.log(`  t() call sites:       ${result.totalCalls}`)
    console.log(`  ${GREEN}✓ hits:${RESET}               ${result.hits}`)
    console.log(`  ${RED}✖ MISSING_KEY:${RESET}        ${missingCount}`)
    console.log(`  ${RED}✖ WRONG_NAMESPACE:${RESET}    ${wrongNsCount}`)
    if (args.hardcoded) {
      console.log(`  ${RED}✖ HARDCODED_STRING:${RESET}   ${hardcodedCount}`)
    }
    console.log(`  ${YELLOW}⚠ DYNAMIC_KEY:${RESET}        ${dynamicCount}`)
    console.log(`  Total blockers:       ${blockers.length}`)
    console.log(`  Total warnings:       ${warnings.length}`)
    console.log(`  Timing:               scan ${scanMs}ms, fetch ${fetchMs}ms`)
  }

  // Exit code logic
  if (args.strict) {
    const hasBlocker = result.issues.some(isBlocker)
    process.exit(hasBlocker ? 1 : 0)
  }
  process.exit(0)
}

main().catch((err) => {
  console.error(`${RED}i18n:check crashed:${RESET}`, err)
  process.exit(2)
})
