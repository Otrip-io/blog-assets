/**
 * AST-based scanner for `t()` translation call sites.
 *
 * For each source file, builds a per-scope binding map of `t`-shaped identifiers
 * to their namespaces (resolved from `useTranslation('ns')`, `useI18n()`, or
 * inline destructure aliases). Then walks every CallExpression and emits
 * `{ file, line, key, namespace }` records for static keys, or marks the call
 * as `dynamic` when the first argument is non-literal.
 *
 * Returns a structured report — the comparison against Tolgee lives in compare.ts.
 */

import { Project, SyntaxKind, type SourceFile, type ScriptTarget } from 'ts-morph'
import { readFile } from 'node:fs/promises'
import { resolve, relative } from 'node:path'
import {
  TRANSLATION_HOOKS, SKIP_PATTERNS, DEFAULT_NAMESPACE,
  HARDCODED_TEXT_COMPONENTS, HARDCODED_TEXT_PROPS,
  SKIP_PROP_NAMES, SKIP_PARENT_COMPONENTS, SKIP_LITERALS,
} from './config.js'

export interface CallSite {
  file: string
  line: number
  column: number
  key: string
  namespace: string
  /** When true, the namespace was passed as the second arg of t(); otherwise inferred from wrapper. */
  explicitNamespace: boolean
}

export interface DynamicSite {
  file: string
  line: number
  column: number
  reason: 'non-literal-key' | 'non-literal-namespace'
  snippet: string
}

export interface HardcodedSite {
  file: string
  line: number
  column: number
  /** The literal string that was found unwrapped */
  text: string
  /** Where the literal was found: a JSX child of `component`, or the value of `prop` on `component`. */
  origin: { kind: 'child'; component: string } | { kind: 'prop'; component: string; prop: string }
  /** A snake_case key suggested for promotion */
  suggestedKey: string
}

export interface ScanResult {
  calls: CallSite[]
  dynamic: DynamicSite[]
  hardcoded: HardcodedSite[]
  filesScanned: number
}

export interface ScanOptions {
  /** When true, walk JSX trees and flag hardcoded user-facing strings. Default: false. */
  detectHardcoded?: boolean
}

/** Identifier name → bound namespace. `null` namespace means "explicit-namespace required at call site". */
type BindingMap = Map<string, string | null>

/** Walk filesystem, return list of .ts/.tsx/.js/.jsx files (skipping node_modules and configured patterns). */
async function collectFiles(roots: string[]): Promise<string[]> {
  const files: string[] = []
  const { readdir, stat } = await import('node:fs/promises')
  for (const root of roots) {
    await walk(root)
  }
  return files

  async function walk(dir: string): Promise<void> {
    let entries: string[]
    try {
      entries = await readdir(dir)
    } catch {
      return
    }
    for (const entry of entries) {
      if (entry.startsWith('.') || entry === 'node_modules' || entry === 'dist' || entry === 'build') continue
      const full = resolve(dir, entry)
      let st
      try {
        st = await stat(full)
      } catch {
        continue
      }
      if (st.isDirectory()) {
        await walk(full)
      } else if (/\.(tsx?|jsx?)$/.test(entry)) {
        if (SKIP_PATTERNS.some((p) => p.test(full))) continue
        files.push(full)
      }
    }
  }
}

/**
 * Build the per-file binding map by walking the AST and recording every
 * `t`-shaped identifier introduced by destructuring a translation hook.
 *
 * Examples:
 *   const { t } = useTranslation('trips')              → { t: 'trips' }
 *   const { t: tt } = useTranslation('chat')           → { tt: 'chat' }
 *   const { t } = useI18n()                            → { t: null }   // explicit ns required at call
 *   const { t: ti, isRTL } = useI18n()                 → { ti: null }
 */
function buildBindings(source: SourceFile): BindingMap {
  const bindings: BindingMap = new Map()

  source.forEachDescendant((node) => {
    if (node.getKind() !== SyntaxKind.VariableDeclaration) return
    const decl = node.asKindOrThrow(SyntaxKind.VariableDeclaration)
    const init = decl.getInitializer()
    if (!init) return
    if (init.getKind() !== SyntaxKind.CallExpression) return
    const call = init.asKindOrThrow(SyntaxKind.CallExpression)
    const callee = call.getExpression()
    if (callee.getKind() !== SyntaxKind.Identifier) return
    const fnName = callee.getText()
    if (!TRANSLATION_HOOKS.has(fnName)) return

    const nameNode = decl.getNameNode()
    if (nameNode.getKind() !== SyntaxKind.ObjectBindingPattern) return
    const pattern = nameNode.asKindOrThrow(SyntaxKind.ObjectBindingPattern)

    // Determine namespace from first arg, if present and a string literal.
    const args = call.getArguments()
    let ns: string | null = null
    if (args.length > 0) {
      const first = args[0]
      if (first.getKind() === SyntaxKind.StringLiteral) {
        ns = first.asKindOrThrow(SyntaxKind.StringLiteral).getLiteralValue()
      } else if (fnName === 'useTranslation') {
        // useTranslation called with non-literal — can't determine ns; skip binding
        return
      }
      // For useI18n with any arg, we still treat it as null-ns (explicit at call site).
    } else if (fnName === 'useTranslation') {
      ns = DEFAULT_NAMESPACE
    }

    // Walk the destructuring pattern for `t` or `t: alias`.
    for (const elem of pattern.getElements()) {
      const propName = elem.getPropertyNameNode()?.getText() ?? elem.getName()
      if (propName !== 't') continue
      const aliasName = elem.getName() // either `t` or the alias
      bindings.set(aliasName, ns)
    }
  })

  return bindings
}

/** Extract translation call sites from one source file. */
function scanFile(source: SourceFile, bindings: BindingMap, relPath: string): {
  calls: CallSite[]
  dynamic: DynamicSite[]
} {
  const calls: CallSite[] = []
  const dynamic: DynamicSite[] = []

  source.forEachDescendant((node) => {
    if (node.getKind() !== SyntaxKind.CallExpression) return
    const call = node.asKindOrThrow(SyntaxKind.CallExpression)
    const callee = call.getExpression()
    if (callee.getKind() !== SyntaxKind.Identifier) return
    const fnName = callee.getText()
    if (!bindings.has(fnName)) return

    const args = call.getArguments()
    if (args.length === 0) return

    const { line, column } = source.getLineAndColumnAtPos(call.getStart())
    const firstArg = args[0]

    // First arg must be a string literal to be statically validated.
    if (firstArg.getKind() !== SyntaxKind.StringLiteral) {
      dynamic.push({
        file: relPath,
        line,
        column,
        reason: 'non-literal-key',
        snippet: trimSnippet(call.getText()),
      })
      return
    }
    const key = firstArg.asKindOrThrow(SyntaxKind.StringLiteral).getLiteralValue()

    // Resolve namespace: explicit second-arg literal wins; else use binding map.
    let namespace = bindings.get(fnName) ?? DEFAULT_NAMESPACE
    let explicitNamespace = false
    if (args.length >= 2) {
      const second = args[1]
      if (second.getKind() === SyntaxKind.StringLiteral) {
        namespace = second.asKindOrThrow(SyntaxKind.StringLiteral).getLiteralValue()
        explicitNamespace = true
      } else if (
        // Common case: `t(key, fallback?)` where fallback is a string we don't want
        // to mistake for a namespace. We only accept second-arg-as-namespace when
        // it is a string-literal that looks like a namespace (no spaces).
        // For any other shape (object params, expression, identifier), fall back
        // to the wrapper's binding if available.
        second.getKind() === SyntaxKind.ObjectLiteralExpression ||
        second.getKind() === SyntaxKind.Identifier ||
        second.getKind() === SyntaxKind.PropertyAccessExpression ||
        second.getKind() === SyntaxKind.ConditionalExpression
      ) {
        // ok — keep wrapper-bound namespace
      } else if (bindings.get(fnName) === null) {
        // Wrapper requires explicit namespace but we got something else — flag as dynamic
        dynamic.push({
          file: relPath,
          line,
          column,
          reason: 'non-literal-namespace',
          snippet: trimSnippet(call.getText()),
        })
        return
      }
    }

    if (namespace === null) {
      // useI18n() destructure where call provided no string namespace — fall back
      // to default and note the absence wasn't explicit.
      namespace = DEFAULT_NAMESPACE
    }

    calls.push({
      file: relPath,
      line,
      column,
      key,
      namespace,
      explicitNamespace,
    })
  })

  return { calls, dynamic }
}

function trimSnippet(text: string): string {
  const oneline = text.replace(/\s+/g, ' ').trim()
  return oneline.length > 100 ? oneline.slice(0, 97) + '...' : oneline
}

function shouldSkipLiteral(text: string): boolean {
  const trimmed = text.trim()
  if (trimmed.length <= 1) return true
  for (const pattern of SKIP_LITERALS) {
    if (typeof pattern === 'string') {
      if (pattern === trimmed) return true
    } else if (pattern.test(trimmed)) {
      return true
    }
  }
  return false
}

function suggestKey(text: string): string {
  const cleaned = text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
  return cleaned.slice(0, 40) || 'translated_string'
}

/**
 * Find hardcoded user-facing strings in JSX:
 *   1. String-literal children of allowlisted components (e.g. `<Text>Save</Text>`)
 *   2. String-literal values of allowlisted text-bearing props (e.g. `placeholder="Enter name"`)
 *
 * Skips: SKIP_PATTERNS files, SKIP_PARENT_COMPONENTS subtrees, SKIP_LITERALS regex,
 * single non-letter chars, empty/whitespace.
 */
function scanHardcoded(source: SourceFile, relPath: string): HardcodedSite[] {
  const sites: HardcodedSite[] = []

  source.forEachDescendant((node) => {
    // Skip subtrees of opt-out components (<code>, <pre>, etc.)
    if (
      node.getKind() === SyntaxKind.JsxElement ||
      node.getKind() === SyntaxKind.JsxSelfClosingElement
    ) {
      const tagName = getTagName(node)
      if (tagName && SKIP_PARENT_COMPONENTS.has(tagName)) {
        // Don't traverse this element's children — return false to skip,
        // but ts-morph forEachDescendant doesn't honor a return value.
        // Mark via a side-channel: we still traverse but check ancestor in the inner check.
      }
    }

    // 1. JSX child string literals (only inside allowlisted components)
    if (node.getKind() === SyntaxKind.JsxText) {
      const jsxText = node.asKindOrThrow(SyntaxKind.JsxText)
      const text = jsxText.getLiteralText()
      if (shouldSkipLiteral(text)) return
      const parent = jsxText.getParentIfKind(SyntaxKind.JsxElement)
      if (!parent) return
      const tagName = getTagName(parent) ?? ''
      if (!HARDCODED_TEXT_COMPONENTS.has(tagName)) return
      if (hasSkipParentAncestor(parent)) return

      const { line, column } = source.getLineAndColumnAtPos(jsxText.getStart())
      const trimmed = text.trim()
      sites.push({
        file: relPath,
        line,
        column,
        text: trimmed,
        origin: { kind: 'child', component: tagName },
        suggestedKey: suggestKey(trimmed),
      })
    }

    // 2. JSX prop string-literal values (any element, allowlisted prop names)
    if (node.getKind() === SyntaxKind.JsxAttribute) {
      const attr = node.asKindOrThrow(SyntaxKind.JsxAttribute)
      const name = attr.getNameNode().getText()
      if (SKIP_PROP_NAMES.has(name)) return
      if (!HARDCODED_TEXT_PROPS.has(name)) return

      const init = attr.getInitializer()
      if (!init) return

      // `prop="literal"` — initializer is a StringLiteral
      // `prop={"literal"}` — initializer is JsxExpression containing a StringLiteral
      let literalText: string | null = null
      if (init.getKind() === SyntaxKind.StringLiteral) {
        literalText = init.asKindOrThrow(SyntaxKind.StringLiteral).getLiteralValue()
      } else if (init.getKind() === SyntaxKind.JsxExpression) {
        const expr = init.asKindOrThrow(SyntaxKind.JsxExpression).getExpression()
        if (expr?.getKind() === SyntaxKind.StringLiteral) {
          literalText = expr.asKindOrThrow(SyntaxKind.StringLiteral).getLiteralValue()
        }
      }

      if (literalText === null) return
      if (shouldSkipLiteral(literalText)) return

      const ownerElement = attr.getFirstAncestorByKind(SyntaxKind.JsxOpeningElement)
        ?? attr.getFirstAncestorByKind(SyntaxKind.JsxSelfClosingElement)
      const ownerName = ownerElement ? getTagNameFromOpening(ownerElement) : 'unknown'
      if (ownerElement && hasSkipParentAncestor(ownerElement)) return

      const { line, column } = source.getLineAndColumnAtPos(attr.getStart())
      sites.push({
        file: relPath,
        line,
        column,
        text: literalText,
        origin: { kind: 'prop', component: ownerName ?? 'unknown', prop: name },
        suggestedKey: suggestKey(literalText),
      })
    }
  })

  return sites
}

function getTagName(node: ReturnType<SourceFile['forEachDescendantAsArray']>[number]): string | null {
  if (node.getKind() === SyntaxKind.JsxElement) {
    const elem = node.asKindOrThrow(SyntaxKind.JsxElement)
    return getTagNameFromOpening(elem.getOpeningElement())
  }
  if (node.getKind() === SyntaxKind.JsxSelfClosingElement) {
    return getTagNameFromOpening(node.asKindOrThrow(SyntaxKind.JsxSelfClosingElement))
  }
  return null
}

function getTagNameFromOpening(elem: { getTagNameNode(): { getText(): string } }): string {
  return elem.getTagNameNode().getText()
}

function hasSkipParentAncestor(node: ReturnType<SourceFile['forEachDescendantAsArray']>[number]): boolean {
  let cur: ReturnType<SourceFile['forEachDescendantAsArray']>[number] | undefined = node.getParent()
  while (cur) {
    if (cur.getKind() === SyntaxKind.JsxElement || cur.getKind() === SyntaxKind.JsxSelfClosingElement) {
      const name = getTagName(cur)
      if (name && SKIP_PARENT_COMPONENTS.has(name)) return true
    }
    cur = cur.getParent()
  }
  return false
}

/** Public API: scan all files under the given roots and return the full report. */
export async function scan(roots: string[], cwd: string = process.cwd(), opts: ScanOptions = {}): Promise<ScanResult> {
  const files = await collectFiles(roots.map((r) => resolve(cwd, r)))

  // ts-morph Project — we use a virtual fs so we don't need a real tsconfig
  const project = new Project({
    useInMemoryFileSystem: false,
    skipAddingFilesFromTsConfig: true,
    skipFileDependencyResolution: true,
    skipLoadingLibFiles: true,
    compilerOptions: {
      allowJs: true,
      jsx: 4 satisfies number, // ReactJSX (avoid importing JsxEmit enum)
      target: 99 as ScriptTarget, // ESNext
      noEmit: true,
    },
  })

  const allCalls: CallSite[] = []
  const allDynamic: DynamicSite[] = []
  const allHardcoded: HardcodedSite[] = []

  for (const file of files) {
    const content = await readFile(file, 'utf8')
    // Quick reject for t()-only mode: file contains no `t(` and no `useTranslation` and no `useI18n`
    const hasTranslationCalls =
      content.includes('useTranslation') ||
      content.includes('useI18n') ||
      /\bt\s*\(/.test(content)
    // For hardcoded mode, we still need to scan even files without t() — they may have raw <Text>.
    if (!opts.detectHardcoded && !hasTranslationCalls) continue

    const source = project.createSourceFile(file, content, { overwrite: true })
    const relPath = relative(cwd, file)

    if (hasTranslationCalls) {
      const bindings = buildBindings(source)
      if (bindings.size > 0) {
        const result = scanFile(source, bindings, relPath)
        allCalls.push(...result.calls)
        allDynamic.push(...result.dynamic)
      }
    }

    if (opts.detectHardcoded) {
      // Only scan JSX-bearing files
      if (file.endsWith('.tsx') || file.endsWith('.jsx')) {
        allHardcoded.push(...scanHardcoded(source, relPath))
      }
    }

    project.removeSourceFile(source)
  }

  return {
    calls: allCalls,
    dynamic: allDynamic,
    hardcoded: allHardcoded,
    filesScanned: files.length,
  }
}
