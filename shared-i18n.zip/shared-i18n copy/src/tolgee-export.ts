#!/usr/bin/env bun
/**
 * tolgee:export — Download all keys (EN only) with their Tolgee key IDs.
 *
 * Output: tolgee-export.json
 *   { "namespace": { "keyName": { "en": "English text", "_id": 12345 } } }
 *
 * Usage:
 *   TOLGEE_API_KEY=tgpak_... bun run tolgee:export
 *   TOLGEE_API_KEY=tgpak_... TOLGEE_URL=https://i18n.otrip.io TOLGEE_PROJECT=2 bun run tolgee:export
 */
import { writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const TOLGEE_URL     = process.env.TOLGEE_URL ?? 'https://i18n.otrip.io'
const TOLGEE_PROJECT = process.env.TOLGEE_PROJECT ?? '2'
const TOLGEE_KEY     = process.env.TOLGEE_API_KEY
const OUTPUT         = resolve(process.cwd(), 'tolgee-export.json')

if (!TOLGEE_KEY) {
  console.error('❌  Set TOLGEE_API_KEY env var (write-scoped key from https://i18n.otrip.io → Account → API Keys)')
  process.exit(1)
}

interface TolgeeKey {
  id: number
  name: string
  namespace?: { id: number; name: string } | null
  translations: { en?: { text: string; state: string } }
}

interface PagedResponse {
  _embedded?: { keys?: TolgeeKey[] }
  page: { totalElements: number; totalPages: number; number: number }
}

async function fetchPage(page: number, size = 500): Promise<PagedResponse> {
  const url = `${TOLGEE_URL}/v2/projects/${TOLGEE_PROJECT}/translations?languages=en&size=${size}&page=${page}`
  const res = await fetch(url, {
    headers: { 'X-API-Key': TOLGEE_KEY!, Accept: 'application/json' },
  })
  if (!res.ok) throw new Error(`Tolgee ${res.status}: ${await res.text()}`)
  return res.json() as Promise<PagedResponse>
}

async function main() {
  console.log(`📥 Downloading all keys from ${TOLGEE_URL} project ${TOLGEE_PROJECT}...`)
  const result: Record<string, Record<string, { en: string; _id: number }>> = {}
  let page = 0
  let total = 0

  while (true) {
    const data = await fetchPage(page)
    const keys = data._embedded?.keys ?? []
    total = data.page.totalElements

    for (const k of keys) {
      const ns = k.namespace?.name ?? 'common'
      const en = k.translations?.en?.text
      if (!en) continue  // skip keys with no English value
      if (!result[ns]) result[ns] = {}
      result[ns][k.name] = { en, _id: k.id }
    }

    process.stdout.write(`\r   Page ${page + 1}/${data.page.totalPages} — ${Object.values(result).reduce((a, v) => a + Object.keys(v).length, 0)} keys loaded`)

    if (page + 1 >= data.page.totalPages) break
    page++
  }

  console.log()
  const keyCount = Object.values(result).reduce((a, v) => a + Object.keys(v).length, 0)
  console.log(`✅ Downloaded ${keyCount}/${total} keys (${total - keyCount} had no EN translation — skipped)`)
  console.log(`   Namespaces: ${Object.keys(result).sort().join(', ')}`)

  await writeFile(OUTPUT, JSON.stringify(result, null, 2), 'utf8')
  console.log(`\n💾 Saved to: ${OUTPUT}`)
  console.log(`\nNext step: bun run tolgee:audit`)
}

main().catch(err => { console.error('❌', err.message); process.exit(1) })
