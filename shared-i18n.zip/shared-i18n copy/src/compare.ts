/**
 * Compares scan results against the live Tolgee bundle.
 *
 * Fetches all keys for the default language directly from Tolgee (or via
 * api-service if no Tolgee API key is provided). Classifies each call site:
 *
 *   MISSING_KEY     — call references key not present in Tolgee at all
 *   WRONG_NAMESPACE — key exists, but under a different namespace
 *
 * Dynamic call sites are passed through unchanged for the CLI to display.
 */

import { type CallSite, type DynamicSite, type HardcodedSite } from './scan.js'

export interface ServerKeys {
  /** namespace → set of key names that exist in Tolgee for the default language */
  byNamespace: Map<string, Set<string>>
  /** key name → list of namespaces it appears in */
  byName: Map<string, string[]>
}

export interface MissingKeyIssue {
  type: 'MISSING_KEY'
  call: CallSite
}

export interface WrongNamespaceIssue {
  type: 'WRONG_NAMESPACE'
  call: CallSite
  existsIn: string[]
}

export interface DynamicKeyIssue {
  type: 'DYNAMIC_KEY'
  site: DynamicSite
}

export interface HardcodedStringIssue {
  type: 'HARDCODED_STRING'
  site: HardcodedSite
}

export type Issue = MissingKeyIssue | WrongNamespaceIssue | DynamicKeyIssue | HardcodedStringIssue

export interface CompareResult {
  issues: Issue[]
  hits: number
  totalCalls: number
}

/** Fetch all keys via api-service `/i18n/en` endpoint. Cheap, no API key needed. */
export async function fetchServerKeys(apiBase: string): Promise<ServerKeys> {
  const url = `${apiBase.replace(/\/$/, '')}/i18n/en`
  const res = await fetch(url, { headers: { Accept: 'application/json' } })
  if (!res.ok) throw new Error(`fetch ${url} failed: ${res.status} ${res.statusText}`)
  const json = (await res.json()) as { data?: { translations?: Record<string, Record<string, string>> } }
  const translations = json.data?.translations ?? {}

  const byNamespace = new Map<string, Set<string>>()
  const byName = new Map<string, string[]>()
  for (const [ns, keys] of Object.entries(translations)) {
    if (!keys || typeof keys !== 'object') continue
    const set = new Set<string>(Object.keys(keys))
    byNamespace.set(ns, set)
    for (const k of Object.keys(keys)) {
      const list = byName.get(k) ?? []
      list.push(ns)
      byName.set(k, list)
    }
  }
  return { byNamespace, byName }
}

export function compare(
  calls: CallSite[],
  dynamic: DynamicSite[],
  hardcoded: HardcodedSite[],
  server: ServerKeys,
): CompareResult {
  const issues: Issue[] = []
  let hits = 0

  for (const call of calls) {
    const nsKeys = server.byNamespace.get(call.namespace)
    if (nsKeys?.has(call.key)) {
      hits++
      continue
    }
    const existsIn = server.byName.get(call.key) ?? []
    if (existsIn.length > 0) {
      issues.push({ type: 'WRONG_NAMESPACE', call, existsIn })
    } else {
      issues.push({ type: 'MISSING_KEY', call })
    }
  }

  for (const site of dynamic) {
    issues.push({ type: 'DYNAMIC_KEY', site })
  }

  for (const site of hardcoded) {
    issues.push({ type: 'HARDCODED_STRING', site })
  }

  return { issues, hits, totalCalls: calls.length }
}
